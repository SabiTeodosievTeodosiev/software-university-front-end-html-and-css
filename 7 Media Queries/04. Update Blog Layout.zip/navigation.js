window.onload = function () {
    let checkbox = document.getElementById("menu-checkbox");
    
    checkbox.checked = true;
    checkbox.onclick = function () {
        let isChecked = checkbox.checked;
        console.log("isChecked = " + isChecked);
        if (isChecked) {
            // console.log(document.querySelector("header>nav").getAttribute("display"));
            document.querySelector("header>nav").style.display = "block";
        } else {
            document.querySelector("header>nav").style.display = "none";
            
        }
    };
};

